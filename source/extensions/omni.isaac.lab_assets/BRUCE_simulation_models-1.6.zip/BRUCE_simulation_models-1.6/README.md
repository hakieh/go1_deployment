# BRUCE Simulation Models

Contains the simulation models of BRUCE-OP robot. Feel Free to grab and play with.

All parts on BRUCE were weight seperatedly so the mass and inertia data is accurate and reliable.

Shout-out to 김준영(Jun Young Kim).
